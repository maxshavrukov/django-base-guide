from django.db import models
from main.models import Product
from django.db.models import Sum, F
from django.contrib.auth.models import User # Импортируем модель пользователя
# Create your models here.

class Order(models.Model):
    user = models.ForeignKey(User, 
                             on_delete=models.CASCADE, 
                             related_name='orders', 
                             blank=True, null=True, 
                             verbose_name='Пользователь')
    first_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=30)
    address = models.CharField(max_length=250)
    comment = models.TextField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    paid = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created']

    def __str__(self):
        return f'Order {self.id}'

    def get_total_cost(self):
        return self.items.aggregate(
            total=Sum(F('price') * F('quantity'))
        )['total'] or 0

class OrderItem(models.Model):
    order = models.ForeignKey(
        Order,
        related_name='items',
        on_delete=models.CASCADE
    )

    product = models.ForeignKey(
        Product,
        related_name='order_items',
        on_delete=models.CASCADE
    )

    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return str(self.id)

    def get_cost(self):
        return self.price * self.quantity
